# Different strategies for balancing dataset:
1. Clustering Undersampling of majority class (HClusteringUnderSampling.ipynb)
2. Random undersampling of majority class & Oversampling of minority class (RUndersample_SMOTE.ipynb) 
3. Clustering undersampling of majority class & Oversampling of minority class (HClustering_USample_SMOTE.ipynb)
